package com.example.bookmarkmanagement;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class listTobrowser extends AppCompatActivity {
    TextView text;
    Button open,delete,favourite;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_tobrowser);
        //setting window pixels
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        getWindow().setLayout((int)(width*0.7),(int)(height*0.5));
        //getting intent value
        Intent intent=getIntent();
        String link = intent.getStringExtra("link");
        text=findViewById(R.id.textView);
        text.setText(link);
        //getting key and url value out off text.
         String s = text.getText().toString();
         int start = s.indexOf("=");
         int end = s.lastIndexOf("/")+1;
         char[] keychar = new char[50];
         s.getChars(0,start,keychar,0);
          char[] urlchar = new char[1000];
         s.getChars(start+1,end,urlchar,0);
         final String key = new String(keychar);
         final String url = new String(urlchar);

        //Toast.makeText(listTobrowser.this,key,Toast.LENGTH_SHORT).show();
         //Toast.makeText(listTobrowser.this,url,Toast.LENGTH_SHORT).show();
        //button activity
        open = findViewById(R.id.button2);
        delete = findViewById(R.id.button4);
        favourite = findViewById(R.id.button3);
        //delete from database
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 databaseReference = FirebaseDatabase.getInstance().getReference("URL");
                 databaseReference.child(key).setValue(null);
                 //not working
                 //Log.i(key,"removed");
                Toast.makeText(listTobrowser.this,key+"removed",Toast.LENGTH_SHORT).show();
            }
        });
        //open on click function
        //working
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });
    }
}
