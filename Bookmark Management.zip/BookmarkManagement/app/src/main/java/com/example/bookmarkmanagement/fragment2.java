package com.example.bookmarkmanagement;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class fragment2 extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment2, container, false);
        Context context = getContext();

        //Toast.makeText(context,"value recieved",Toast.LENGTH_SHORT).show();
       /* ListView listView = (ListView) view.findViewById(R.id.listview);
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add(add);
        assert context != null;
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context, R.layout.list, arrayList);
        listView.setAdapter(arrayAdapter);*/
        return view;
    }
}
