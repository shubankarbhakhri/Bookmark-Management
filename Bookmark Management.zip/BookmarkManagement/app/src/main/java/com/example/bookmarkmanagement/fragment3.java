package com.example.bookmarkmanagement;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.FirebaseDatabase;

import java.net.URL;


public class fragment3 extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        String URL = "https://www.google.com/";
       /* Context context = getContext();
        String s1 = context.toString();
        Toast.makeText(getContext(),s1,Toast.LENGTH_SHORT).show();*/
        View view = inflater.inflate(R.layout.fragment3,container,false);
        final WebView webView = (WebView) view.findViewById(R.id.webview);
        webView.setWebViewClient(new myWebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLoadsImagesAutomatically(true);
       /* String link = getActivity().getIntent().getExtras().getString("URL");
        if(link!="")
        {
            URL=link;
        }*/
        webView.loadUrl(URL);
        FloatingActionButton fab = (FloatingActionButton)view.findViewById(R.id.fab);
        fab.setImageDrawable(ContextCompat.getDrawable(getContext(),R.drawable.plus));
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = webView.getUrl();
                Intent intent = new Intent(getContext(), form.class);
                intent.putExtra("url", url);
                startActivity(intent);
            }    });


        return view;
    }

    private void loadlink(String link)
    {

    }


    private class myWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }

    }
}
