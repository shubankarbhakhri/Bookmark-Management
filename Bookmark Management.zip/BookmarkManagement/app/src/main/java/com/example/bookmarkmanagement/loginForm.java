package com.example.bookmarkmanagement;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class loginForm extends AppCompatActivity
{
    private FirebaseAuth mAuth;
    EditText e1,e2;
    //register the user function
    private void register(String email, String password)
    {
        if (email.equals("") || password.equals("")) {
            Toast.makeText(loginForm.this, "email or password is empty", Toast.LENGTH_SHORT).show();
        } else if (password.length() < 6) {
            Toast.makeText(loginForm.this, "password is less than 6 characters", Toast.LENGTH_SHORT).show();
        } else
            {
            mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {

                    if (task.isSuccessful()) {
                        // Sign in success, update UI with the signed-in user's information
                        Log.d("", "createUserWithEmail:success");
                        e2.setText("");
                        e1.setText("");
                        Toast.makeText(loginForm.this, "Registeration Succcessful",
                                Toast.LENGTH_SHORT).show();
                    }
                    else
                        {
                        // If sign in fails, display a message to the user.
                        Log.w("", "createUserWithEmail:failure", task.getException());
                        Toast.makeText(loginForm.this, "Authentication failed.",
                                Toast.LENGTH_SHORT).show();

                    }
                }
            });
        }
    }

    //login user function
    private void login(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    // Sign in success
                    Intent intent = new Intent(loginForm.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                    Log.d("", "signInWithEmail:success");
                } else {
                    // If sign in fails
                    Log.w("", "signInWithEmail:failure", task.getException());
                    Toast.makeText(loginForm.this, "Authentication failed.",
                            Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_form);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        //to keep the user logged in
        if (user != null) {
            // User is signed in
            Intent i = new Intent(loginForm.this, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        } else {
            // User is signed out
            Log.d("", "onAuthStateChanged:signed_out");
        }
        //crating register button on click
        mAuth = FirebaseAuth.getInstance();
        Button register = findViewById(R.id.button3);
        register.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                 e1 = findViewById(R.id.editText3);
                 e2 = findViewById(R.id.editText4);
                String email = e1.getText().toString();
                String password = e2.getText().toString();
                register(email,password);
            }
        });
        //creating login on click
        Button b2 = findViewById(R.id.button5);
        b2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                EditText e1 = findViewById(R.id.editText3);
                EditText e2 = findViewById(R.id.editText4);
                String email = e1.getText().toString();
                String password = e2.getText().toString();
                if (email.equals("") || password.equals(""))
                {
                    Toast.makeText(loginForm.this, "email or password is empty", Toast.LENGTH_SHORT).show();
                }
                else
                    {
                        login(email,password);
                    }
            }
        });
    }
}




