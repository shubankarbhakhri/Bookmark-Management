package com.example.bookmarkmanagement;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Objects;
public class fragment1 extends Fragment {
    String key;
    ListView listView;
    private FirebaseAuth auth;
    private FirebaseUser user;
    private DatabaseReference databaseReference;

    Context context;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment1, container, false);
        final Context context = getContext();
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        listView = (ListView)view.findViewById(R.id.listview);
        final ArrayList<String> arrayList = new ArrayList<>();
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getContext(),R.layout.list,arrayList);
        listView.setAdapter(arrayAdapter);
        //adding values to list view
            databaseReference = FirebaseDatabase.getInstance().getReference().child(user.getUid()).child("URL");
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    arrayList.clear();
                    for (DataSnapshot Snapshot : dataSnapshot.getChildren()) {
                        key = Snapshot.getKey();
                        arrayList.add(Snapshot.getKey().toString()+" = "+Snapshot.getValue().toString());

                    }
                    arrayAdapter.notifyDataSetChanged();
                }

                // +"="+Snapshot.getValue().toString()
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });


        //creating on click for listview
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(final AdapterView<?> parent, View view, final int position, long id) {
                final String item = (String) parent.getItemAtPosition(position);
                String[] singleChoiceItems = getResources().getStringArray(R.array.dialog_single_choice_array);
                int itemSelected = 0;
                new AlertDialog.Builder(context)
                        .setTitle("Choose")
                        .setSingleChoiceItems(singleChoiceItems, itemSelected, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int selectedIndex) {
                                if(selectedIndex==0)
                                {
                                    Intent i = new Intent(Intent.ACTION_VIEW);
                                    i.setData(Uri.parse(item));
                                    startActivity(i);
                                }
                                if(selectedIndex==1)
                                {
                                    databaseReference = FirebaseDatabase.getInstance().getReference();
                                    databaseReference.child(user.getUid()).child("URL").child(key).removeValue();
                                    Toast.makeText(getContext(),"Deleted",Toast.LENGTH_SHORT).show();

                                }
                                if(selectedIndex==2)
                                {
                                    databaseReference = FirebaseDatabase.getInstance().getReference();
                                    databaseReference.child(user.getUid()).child("Favourite").push().setValue(item);
                                    Toast.makeText(getContext(),"Added",Toast.LENGTH_SHORT).show();
                                }

                            }
                        })
                        .show();





            }
        });
        return view;
    }


}









