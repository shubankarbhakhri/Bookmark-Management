package com.example.bookmarkmanagement;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterAboutUs extends RecyclerView.Adapter {
    private static final String TAG = "AdapterAboutUs";

    ArrayList<RecyclerViewGetterClass> mRecyclerViewGetterClass ;
    AboutUsRecyclerViewClickedListenr mAboutUsRecyclerViewClickedListenr ;
    boolean isExpanded ;

    public AdapterAboutUs(ArrayList<RecyclerViewGetterClass> recyclerViewGetterClass){
        this.mRecyclerViewGetterClass = recyclerViewGetterClass ;
//        this.mAboutUsRecyclerViewClickedListenr = aboutUsRecyclerViewClickedListenr ;
    }
    public interface AboutUsRecyclerViewClickedListenr {
        void AboutUsRecyclerViewClicked(int position);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view ;
        RecyclerView.ViewHolder viewHolder ;

        view = LayoutInflater.
                from(parent.getContext()).inflate(R.layout.about_recyclerview, parent, false);
        viewHolder = new AboutUsView(view,mAboutUsRecyclerViewClickedListenr) ;

        return viewHolder ;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        AboutUsGetterClass aboutUsGetterClass  =
                (AboutUsGetterClass) mRecyclerViewGetterClass.get(position).getObject();
        ((AboutUsView)holder).setAboutUsDataContent(aboutUsGetterClass);

    }

    @Override
    public int getItemCount() {
        return  mRecyclerViewGetterClass.size() ;
    }

    class AboutUsView extends RecyclerView.ViewHolder implements  View.OnClickListener {

        AboutUsRecyclerViewClickedListenr mAboutUsRecyclerViewClickedListenr ;
        TextView titleTv , contentTv ;
        RelativeLayout expandableView ;

        public AboutUsView(@NonNull View itemView,
                                   AboutUsRecyclerViewClickedListenr aboutUsRecyclerViewClickedListenr) {
            super(itemView);
            this.mAboutUsRecyclerViewClickedListenr = aboutUsRecyclerViewClickedListenr;
            titleTv = itemView.findViewById(R.id.titleTv);
            contentTv = itemView.findViewById(R.id.contentTv);
            expandableView = itemView.findViewById(R.id.expandableView);

//            itemView is used to make the wholw recyclerView be used as click button.
            titleTv.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if(view.getId() == titleTv.getId()){

                Log.d(TAG, "onClick() isExpanded value "+isExpanded);
                AboutUsGetterClass aboutUsGetterClass  =
                        (AboutUsGetterClass) mRecyclerViewGetterClass.get(getAdapterPosition()).getObject();
                aboutUsGetterClass.setExpanded(!aboutUsGetterClass.getExpanded());
                notifyItemChanged(getAdapterPosition());
            }
        }
        void setAboutUsDataContent(AboutUsGetterClass aboutUsGetterClass){
            titleTv.setText(aboutUsGetterClass.getAboutUsTitle());
            contentTv.setText(aboutUsGetterClass.getAboutUsContent());
            isExpanded = aboutUsGetterClass.getExpanded() ;
            expandableView.setVisibility(isExpanded ? View.VISIBLE : View.GONE);
            Log.d(TAG, "setAboutUsDataContent() isExpanded value "+isExpanded);
        }
    }
}
