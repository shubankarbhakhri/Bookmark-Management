package com.example.bookmarkmanagement;

import android.util.Log;

public class AboutUsGetterClass {
    private static final String  TAG = "AboutUsGetterClass";

    // data to be fetched here and shown on the recyclerview via rv object passed here
    private String mTitle ;
    private String mContent;
    private boolean isExpanded ;


    public AboutUsGetterClass(String title , String content){
        Log.d(TAG, "AboutUsGetterClass() is called ");
        this.mTitle = title;
        this.mContent = content ;
        this.isExpanded = false ;
    }
    public void setExpanded(boolean expanded){
        this.isExpanded = expanded ;
    }
    public String getAboutUsTitle(){
        return mTitle ;
    }
    public String getAboutUsContent(){
        return mContent;
    }
    public boolean getExpanded(){
        return isExpanded ;
    }
}
