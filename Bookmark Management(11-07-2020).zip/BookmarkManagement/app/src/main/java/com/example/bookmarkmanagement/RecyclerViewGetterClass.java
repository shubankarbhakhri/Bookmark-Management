package com.example.bookmarkmanagement;

import android.util.Log;

public class RecyclerViewGetterClass {

    private static final String  TAG = "RecyclerViewGetterClass";
    private Object mObject ;

    public RecyclerViewGetterClass(Object object){
        Log.d(TAG, "RecyclerViewGetterClass() is called ");
        this.mObject = object ;
    }

    public Object getObject(){
        return mObject ;
    }
}
