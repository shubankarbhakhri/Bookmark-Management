package com.example.bookmarkmanagement;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;
public class fragment2 extends Fragment {
    ListView listView;
    String key;
    DatabaseReference databaseReference;
    private FirebaseAuth auth;
    private FirebaseUser user;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment2, container, false);
        final Context context = getContext();
        final ArrayList<String> arrayList = new ArrayList<>();
        assert context != null;
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        listView = (ListView)view.findViewById(R.id.listview1);
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context, R.layout.list, arrayList);
        listView.setAdapter(arrayAdapter);
        //adding values to list view
         databaseReference = FirebaseDatabase.getInstance().getReference().child(user.getUid()).child("Favourite");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                arrayList.clear();
                for(DataSnapshot Snapshot:dataSnapshot.getChildren())
                {
                    arrayList.add(Snapshot.getValue().toString());
                    key = Snapshot.getKey();
                }
                arrayAdapter.notifyDataSetChanged();
            }
            // +"="+Snapshot.getValue().toString()
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError)
            {

            }
        });
        //creating on click for listview
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final String item = (String) parent.getItemAtPosition(position);
                String[] singleChoiceItems = getResources().getStringArray(R.array.dialog_single_choice_array2);
                int itemSelected = 0;
                new AlertDialog.Builder(context)
                        .setTitle("Choose")
                        .setSingleChoiceItems(singleChoiceItems, itemSelected, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int selectedIndex) {
                                if(selectedIndex==0)
                                {
                                    Intent i = new Intent(Intent.ACTION_VIEW);
                                    i.setData(Uri.parse(item));
                                    startActivity(i);
                                }
                                if(selectedIndex==1)
                                {

                                    databaseReference.child(key).removeValue();
                                    Toast.makeText(getContext(),"Deleted",Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .show();


            }
        });
        return view;
    }
}
