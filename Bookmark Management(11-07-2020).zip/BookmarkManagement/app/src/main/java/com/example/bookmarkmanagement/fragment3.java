package com.example.bookmarkmanagement;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.net.URL;

public class fragment3 extends Fragment {
    int flagForButton = 0;
    String url,save;
    String URL;
     WebView webView;
    EditText search;
    private FirebaseAuth auth;
    private FirebaseUser user;
    private DatabaseReference databaseReference;
    @Nullable
    @Override

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        URL = "";
        final Context context = getContext();
        save="Save";
        final View view = inflater.inflate(R.layout.fragment3,container,false);
        search = view.findViewById(R.id.searchBar);
        search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean handled = false;
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    URL = search.getText().toString();
                    webView = (WebView) view.findViewById(R.id.webview);
                    webView.setWebViewClient(new myWebViewClient());
                    webView.getSettings().setJavaScriptEnabled(true);
                    webView.getSettings().setLoadsImagesAutomatically(true);
                    webView.loadUrl(URL);

                    handled = true;
                }
                return handled;
            }
        });
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        final Button fab = view.findViewById(R.id.button2);
                fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                url = webView.getUrl();
                Intent intent = new Intent(getContext(), form.class);
                intent.putExtra("url", url);
                startActivity(intent);

            }});
        return view;
    }
    private void loadlink(String link)
    {

    }
    private class myWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }

    }
}
