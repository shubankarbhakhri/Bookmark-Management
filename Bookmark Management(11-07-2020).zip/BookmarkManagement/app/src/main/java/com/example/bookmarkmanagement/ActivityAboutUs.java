package com.example.bookmarkmanagement;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Objects;

import com.example.bookmarkmanagement.AboutUsGetterClass;
import com.example.bookmarkmanagement.AdapterAboutUs;
import com.example.bookmarkmanagement.RecyclerViewGetterClass;

public class ActivityAboutUs extends AppCompatActivity {
    private static final String TAG = "ActivityAboutUs" ;

    RecyclerView aboutUsRecyclerView ;
    AdapterAboutUs mAdapterAboutUs ;
    AboutUsGetterClass mAboutUsGetterClass ;
    ArrayList<RecyclerViewGetterClass> mRecyclerViewGetterClass = new ArrayList<>();


    private void InitRecyclerAboutUs() {
        Log.d(TAG, "initRecyclerView() initialized aboutUsRecyclerView ");

        LinearLayoutManager linearLayoutManager =
                new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,false);
        aboutUsRecyclerView = findViewById(R.id.aboutUsRecyclerView);
        aboutUsRecyclerView.setLayoutManager(linearLayoutManager);
        mAdapterAboutUs = new AdapterAboutUs(mRecyclerViewGetterClass);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        InitRecyclerAboutUs();
        putDataForAboutUs();
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        finish();
        return true;
    }
    private void putDataForAboutUs(){
        mRecyclerViewGetterClass.add(new RecyclerViewGetterClass(
                new AboutUsGetterClass(getString(R.string.about_title3),getString(R.string.about_content3))));
        mRecyclerViewGetterClass.add(new RecyclerViewGetterClass(
                        new AboutUsGetterClass(getString(R.string.about_title0),getString(R.string.about_content0))));
        mRecyclerViewGetterClass.add(new RecyclerViewGetterClass(
                new AboutUsGetterClass(getString(R.string.about_title1),getString(R.string.about_content1))));
        mRecyclerViewGetterClass.add(new RecyclerViewGetterClass(
                new AboutUsGetterClass(getString(R.string.about_title2),getString(R.string.about_content2))));
        mRecyclerViewGetterClass.add(new RecyclerViewGetterClass(
                new AboutUsGetterClass(getString(R.string.about_title4),getString(R.string.about_content4))));
        mRecyclerViewGetterClass.add(new RecyclerViewGetterClass(
                new AboutUsGetterClass(getString(R.string.about_title5),getString(R.string.about_content5))));
        mRecyclerViewGetterClass.add(new RecyclerViewGetterClass(
                new AboutUsGetterClass(getString(R.string.about_title6),getString(R.string.about_content6))));
        // setting up the adapter here :
        aboutUsRecyclerView.setAdapter(mAdapterAboutUs);
    }
}